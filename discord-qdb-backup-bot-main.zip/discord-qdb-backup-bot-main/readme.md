# GEREKLİ BİLGİLER
config.json dosyasını doldurun

Terminale ``npm install`` yazıp modülleri kurun

Terminalde ``node .`` yazarak botu başlatabilirsiniz 🎉🎉

# ÖNEMLİ BİLGİLER
Glitch kullanan arkadaşlar glitche uygun package kullanmalıdır yoksa botunuz aktif olmaz

Botta MIT lisansı vardır haberiniz olsun benimdir diye dolaşanlara lisans üzerinden gerekli işlemler yapılacaktır

# PROJE HAKKINDA
botta sadece ``backup-kur rol id`` ile rol dağıtabilirsiniz rolü sileni banlamaz sadece bilgilendirme mesajı için rol ismi/id sini atar şuanlık kanal izni ayarlama yok ama 35 stara ulaştığında hem kanal perm sistemi hemde destekçi tokenler ile dağıtma sistemini ekleyeceğim danger mod ise eğer false değerini true olarak değiştirirseniz otomatik olarak sunucu rol backıbını almaz buna dikkat edin iyi kullanımlar Ayrıca rolü dağıtıyor merak etmeyin sadece rate limite girdiği için arada durabilir haberiniz olsun
